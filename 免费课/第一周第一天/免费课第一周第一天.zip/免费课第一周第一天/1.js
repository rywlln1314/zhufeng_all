/*
div1.onclick = function () {
    alert(2);
}*/
